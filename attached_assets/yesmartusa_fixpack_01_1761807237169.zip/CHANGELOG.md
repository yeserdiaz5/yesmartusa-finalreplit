# Fix Pack 01 — YesMartUSA / Shipments + RLS

## Archivos añadidos
- `app/actions/shipengine.ts`
  - Server Action que usa `SUPABASE_SERVICE_ROLE_KEY` para insertar en `shipments` desde el servidor, ignorando RLS en producción.
  - Recibe (orderId, rateId, serviceCode, lengthIn, widthIn, heightIn, weightOz, userId?).
  - Inserta `user_id` si lo envías para habilitar la policy de SELECT por dueño.

- `.env.example`
  - Lista de variables necesarias en Vercel:
    - `NEXT_PUBLIC_SUPABASE_URL`
    - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
    - `SUPABASE_SERVICE_ROLE_KEY`
    - `SHIPENGINE_API_KEY` (si usas ShipEngine)

- `supabase/policies.sql`
  - Activa RLS en `public.shipments` y añade:
    - INSERT público para `anon`.
    - SELECT restringido por dueño (columna `user_id`).

## Pasos para aplicar
1. Copia `app/actions/shipengine.ts` dentro de tu proyecto (reemplaza si ya existe).
2. Copia `.env.example` a la raíz (solo como referencia).
3. En Vercel → Settings → Environment Variables, define:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (Server-only; **no** NEXT_PUBLIC)
   - `SHIPENGINE_API_KEY` (si aplica)
4. En Supabase → SQL Editor, pega y ejecuta el contenido de `supabase/policies.sql` (ajusta el nombre de la tabla si no es `shipments`).
5. Despliega en Vercel.
6. Si filtras por dueño, pasa `userId` a `purchaseLabelForOrder(...)` para grabarlo en `shipments.user_id`.
